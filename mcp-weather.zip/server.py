from fastapi import FastAPI
import requests
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

API_KEY = os.getenv("OPENWEATHER_API_KEY")

@app.post("/tools/get_weather")
def get_weather(city: str):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"

    response = requests.get(url).json()

    if response.get("cod") != 200:
        return {"error": "City not found"}

    return {
        "city": city,
        "temperature": response["main"]["temp"],
        "weather": response["weather"][0]["description"]
    }

@app.get("/tools")
def list_tools():
    return {
        "tools": [
            {
                "name": "get_weather",
                "description": "Get current weather for a city",
                "input": {
                    "city": "string"
                }
            }
        ]
    }
