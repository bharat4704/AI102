# MCP Weather Server

## Setup

1. Install dependencies:
   pip install -r requirements.txt

2. Add your API key in .env

3. Run server:
   uvicorn server:app --reload

## Endpoints

GET /tools
POST /tools/get_weather?city=London
